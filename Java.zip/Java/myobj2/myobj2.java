public class myobj2
{
    public static void main(String args[])
    {
        animal a = new animal();
        dog d = new dog();
        cat c = new cat();
        cat b = new cat(5);
        cat e = new cat(6, 10);

        a.move();
        d.move();
        c.move();
        b.jump();

        d.setage(10);
        System.out.println("�����~����: " + d.getage() + "��");

        c.output();
        b.output();
        e.output();
    }
}