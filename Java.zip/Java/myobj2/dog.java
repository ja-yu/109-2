class dog extends animal
{

    public void move()
    {
        System.out.println("�ڬO���A�ڷ|�]");
    }

    public void setage(int a)
    {
        age = a;
    }
}