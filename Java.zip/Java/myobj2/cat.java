class cat extends animal
{
    int weight;

    cat()
    {
        age = 3;
        weight = 3;
    }

    cat(int a)
    {
        age = a;
        weight = 3;
    }

    cat(int a, int w)
    {
        age = a;
        weight = w;
    }

    public void move()
    {
        System.out.println("�ڬO�ߡA�ڷ|�]");
    }

    public void jump()
    {
        System.out.println("�ڬO�ߡA�ڷ|��");
    }

    public void output()
    {
        System.out.println("�o����" + age + "��");
        System.out.println("�o����" + weight + "���筫");
    }


}