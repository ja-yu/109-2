public class std
{
    String id, name;
    int chi, eng, mat, pro1, pro2;

    std(String id, String name, int c, int e, int m, int p1, int p2)
    {
        this.id = id;
        this.name = name;
        chi = c;
        eng = e;
        mat = m;
        pro1 = p1;
        pro2 = p2;
    }

    public int sum_score()
    {
        return chi + eng + mat + pro1 + pro2;
    }

    public float avg_score()
    {
        return sum_score()/5;
    }

    public double weight_score()
    {
        float s1 = (chi + eng + mat)/3;
        return s1 + pro1 * 1.1 + pro2 * 1.1;
    }
};