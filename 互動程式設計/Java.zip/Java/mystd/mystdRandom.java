public class mystdRandom
{
    public static void main(String [] args)
    {
        std[] stds = new std[5];
        String[] name = {"���@", "���G", "�]�T", "���|", "�P��"};

        for(int i = 0; i < 5; i++)
        {
            int c = (int)(Math.random() * 10 + 80);
            int e = (int)(Math.random() * 10 + 80);
            int m = (int)(Math.random() * 10 + 80);
            int p1 = (int)(Math.random() * 10 + 80);
            int p2 = (int)(Math.random() * 10 + 80);
            
            stds[i] = new std(String.valueOf(i), name[i], c, e, m, p1, p2);

            System.out.println("�o�Ӿǥ;Ǹ�: "+ stds[i].id);
            System.out.println("�o�ӾǥͦW�r: "+ stds[i].name);
            System.out.println("�o�Ӿǥ��`���Z: "+ stds[i].sum_score());
            System.out.println("�o�Ӿǥͥ�������: "+ stds[i].avg_score());
            System.out.println("�o�Ӿǥͥ[�v����: "+ stds[i].weight_score());
            System.out.println("====================================");
        }
    }
}