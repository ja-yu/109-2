class animal
{
    int age;

    public void move()
    {
        System.out.println("�ڬO�ʪ��A�ڷ|�]");
    }

    public int getage()
    {
        return age;
    }
}