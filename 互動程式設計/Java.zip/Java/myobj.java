// overloading

public class myobj
{
    public static void main(String args[])
    {
        myobj obj = new myobj();
        int a1 = obj.sum(10, 10, 10);
        System.out.println(a1);
        int a2 = obj.sum(20, 20);
        System.out.println(a2);
    }

    int sum(int a, int b, int c)
    {
        return a+b+c;
    }

    int sum(int a, int b)
    {
        return a+b;
    }
}