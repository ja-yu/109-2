import java.awt.*;
import javax.swing.*;

public class awt00
{
    public static void main(String[] args)
    {
        Frame myframe = new Frame();
        ImageIcon myicon;
        myicon = new ImageIcon("home.png");
        myframe.setTitle("�ڪ������{��");
        myframe.setResizable(true);
        myframe.setIconImage(myicon.getImage());
        myframe.setSize(320, 240);
        myframe.setLocation(600, 600);
        myframe.setForeground(Color.BLUE);
        myframe.setBackground(Color.GRAY);
        myframe.setVisible(true);
    }
}